console.log("NotebookLM Directory Manager Loaded");

const NotebookManager = {
  notebookId: null,
  sources: [],
  notes: [],
  displayMode: 'single', 
  collapsedFolderIds: [], 
  searchQuery: '', // 4.12: 搜索内容
  isDeepMode: true, // 4.23: 默认开启深度集成以支持隐藏原生列表
  editingFolderId: null, // 4.35: 正在编辑名称的文件夹 ID
  isSearchOpen: false, // 4.60: 搜索面板显示状态
  isComposing: false, // 4.61: IME 输入状态
  sidebarObserver: null, // 4.62: 监听侧边栏尺寸
  currentSidebarWidth: 0, // 4.62: 宽缓存
  currentSidebarLeft: 0,  // 4.62: 偏移缓存
  licenseInfo: null,     // v1.1: 许可证信息
  isRendering: false,    // 4.10: 渲染锁，防止并发冲突
  lastContainerFixTime: 0, // 4.10: 容器修复冷却计时
  scanTimer: null,       // 4.10: 扫描防抖定时器

  async init() {
    this.notebookId = StorageManager.extractNotebookId();
    if (!this.notebookId) return;

    // 4.2: 注入 Material Symbols 字体
    if (!document.getElementById('nb-ext-material-icons')) {
      const link = document.createElement('link');
      link.id = 'nb-ext-material-icons';
      link.rel = 'stylesheet';
      link.href = 'https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20,400,0,0';
      document.head.appendChild(link);
    }

    // 加载用户持久化设置
    const settings = await chrome.storage.local.get(['nb_ext_tree_enabled', 'nb_ext_display_mode', 'nb_ext_collapsed_ids']);
    if (settings.nb_ext_tree_enabled !== undefined) this.treeViewEnabled = settings.nb_ext_tree_enabled;
    if (settings.nb_ext_display_mode !== undefined) this.displayMode = settings.nb_ext_display_mode;
    if (settings.nb_ext_collapsed_ids !== undefined) this.collapsedFolderIds = settings.nb_ext_collapsed_ids;

    console.log("NotebookID identified:", this.notebookId);
    
    // 给 body 加上标记位
    if (this.isDeepMode) document.body.classList.add('nb-ext-deep-mode');

    // 监听 URL 变化
    let lastUrl = location.href;
    setInterval(() => {
      if (location.href !== lastUrl) {
        lastUrl = location.href;
        this.notebookId = StorageManager.extractNotebookId();
        this.refreshData();
      }
    }, 1000); // 4.10: 提高频率至 1s 以应对快速回退

    this.observer = new MutationObserver(() => {
      if (this.scanTimer) clearTimeout(this.scanTimer);
      this.scanTimer = setTimeout(() => this.scanDom(), 500); // 4.10: 500ms 防抖，进一步降低背景扫描率
    });
    this.observer.observe(document.body, { childList: true, subtree: true });
    
    // 4.20/4.21: 基于 ResizeObserver 精准监听侧边栏物理宽度
    this.resizeObserver = new ResizeObserver(entries => {
      for (const entry of entries) {
        const width = entry.borderBoxSize ? entry.borderBoxSize[0].inlineSize : entry.contentRect.width;
        
        // 4.21: 强制 Inline Style 控制，防止 Angular 官方高权重样式覆盖
        const toolbar = document.querySelector('.nb-ext-toolbar');
        const searchInput = document.querySelector('.nb-ext-search-container');
        
        // 4.65: 核心对齐 - 缩放时实时同步容器尺寸
        // 显隐逻辑已整合进 syncContainerSize
        this.syncContainerSize();
      }
    });

    this.refreshData();
  },

  async checkLicense() {
    this.licenseInfo = await StorageManager.getLicenseInfo();
    const now = Date.now();
    const trialPeriod = this.licenseInfo.trialDays * 24 * 60 * 60 * 1000;
    const isExpired = !this.licenseInfo.isLicensed && (now - this.licenseInfo.installDate > trialPeriod);
    this.licenseInfo.isExpired = isExpired;
    return this.licenseInfo;
  },

  async refreshData() {
    try {
      await this.checkLicense();
      this.scanDom();
      const config = await StorageManager.getNotebookConfig(this.notebookId);
      this.renderSidebarUI(config);
    } catch (e) {
      if (e.message.includes('Extension context invalidated')) {
        console.log("[NB-Ext] Extension context invalidated, stopping refreshes.");
      } else {
        console.error("[NB-Ext] Refresh error:", e);
      }
    }
  },

  // 4.65: 精准对齐到原生滚动区域的大小和位置核心方法
  syncContainerSize() {
    const container = document.getElementById('nb-ext-container');
    const toolbar = document.querySelector('.nb-ext-toolbar');
    const scrollArea = document.querySelector('.scroll-area-desktop') || document.querySelector('.mat-drawer-inner-container');
    const sidebarContent = scrollArea ? scrollArea.parentElement : document.querySelector('[class*="source-panel"]');

    if (!container) return;

    if (scrollArea && sidebarContent) {
      const targetRect = scrollArea.getBoundingClientRect();
      const parentRect = sidebarContent.getBoundingClientRect();
      const width = targetRect.width;

      // 4.72: 精准检测收缩类名（原生标识）
      const isNativeCollapsed = nativeHeader && (
        nativeHeader.classList.contains('panel-header-collapsed') || 
        nativeHeader.parentElement?.classList.contains('panel-header-collapsed')
      );

      // 4.66: 整合收缩/隐藏逻辑
      if (width >= 150 && !isNativeCollapsed) {
        document.body.classList.remove('nb-ext-is-collapsed');
        container.style.display = 'flex';
        if (toolbar) toolbar.style.removeProperty('display');
        
        // 4.68: 强制设置原生滚动区隐藏（由用户指示，双重保险）
        scrollArea.style.visibility = 'hidden';

        if (getComputedStyle(sidebarContent).position === 'static') {
          sidebarContent.style.position = 'relative';
        }
        container.style.top = `${targetRect.top - parentRect.top}px`;
        container.style.left = `${targetRect.left - parentRect.left}px`;
        container.style.width = `${targetRect.width}px`;
        container.style.height = `${targetRect.height}px`;
      } else {
        // 宽度不足 (0-149) 判定为收缩或切换中
        if (width > 0) document.body.classList.add('nb-ext-is-collapsed');
        container.style.display = 'none';
        if (toolbar) toolbar.style.setProperty('display', 'none', 'important');
        
        // 恢复原生可见性以防收缩态下完全看不见（如果设计需要）
        scrollArea.style.visibility = 'visible';
      }
    } else {
      // 找不到滚动区，说明在二级界面（如“添加源”），彻底隐藏插件，显示原生内容
      container.style.display = 'none';
      if (toolbar) toolbar.style.setProperty('display', 'none', 'important');
      if (scrollArea) scrollArea.style.visibility = 'visible';
    }
  },

  scanDom() {
    const scrollArea = document.querySelector('.scroll-area-desktop') || document.querySelector('.mat-drawer-inner-container');
    const container = document.getElementById('nb-ext-container');

    // 4.67: 自动恢复监测 - 如果滚动区回来了但 UI 还在隐藏/丢失状态，强制由于重刷
    const isMissing = !container || !document.contains(container);
    const isHiddenButShouldShow = container && container.style.display === 'none' && scrollArea && scrollArea.offsetWidth >= 150;
    const forceRender = isMissing || isHiddenButShouldShow;

    if (!scrollArea) {
      this.syncContainerSize(); // 同步显隐状态（会执行隐藏）
      return;
    }

    // 捕获 Sources
    let sourceElements = scrollArea.querySelectorAll('.source-stretched-button');
    let noteElements = scrollArea.querySelectorAll('.artifact-stretched-button');

    // 容错：如果找不到标准类名，抓取该区域下所有包含 stretched-button 的按钮
    if (sourceElements.length === 0 && noteElements.length === 0) {
      sourceElements = scrollArea.querySelectorAll('button[class*="stretched-button"]');
    }

    const newSources = Array.from(sourceElements).map(el => {
      const parent = el.closest('.mat-mdc-list-item') || el.parentElement;
      const checkbox = parent.querySelector('input.mdc-checkbox__native-control');
      const moreBtn = parent.querySelector('[id^="source-item-more-button-"]');
      const name = el.getAttribute('aria-label') || el.innerText || "Unknown Source";
      // 容错 ID：如果找不到“更多”按钮，则生成基于名称的稳定 ID
      const id = moreBtn ? moreBtn.id.replace('source-item-more-button-', '') : `auto-src-${name.replace(/\s+/g, '')}`;
      return { id, name, element: el, checkbox: checkbox };
    });

    const newNotes = Array.from(noteElements).map(el => {
      const parent = el.closest('.mat-mdc-list-item') || el.parentElement;
      const checkbox = parent.querySelector('input.mdc-checkbox__native-control');
      const moreBtn = parent.querySelector('[id^="artifact-more-button-"]');
      const name = el.getAttribute('aria-label') || el.innerText || "Unknown Note";
      const id = moreBtn ? moreBtn.id.replace('artifact-more-button-', '') : `auto-nt-${name.replace(/\s+/g, '')}`;
      return { id, name, element: el, checkbox: checkbox };
    });

    const hasDataChanged = JSON.stringify(newSources.map(s => s.id)) !== JSON.stringify(this.sources.map(s => s.id)) ||
                           JSON.stringify(newNotes.map(n => n.id)) !== JSON.stringify(this.notes.map(n => n.id));

    if (hasDataChanged || forceRender) {
      if (this.isRendering) return; // 正在渲染中，跳过本次扫描

      // 4.10: 冷却机制 - 如果数据没变只是由于容器丢失/隐藏触发，防止瞬时高频重扫
      if (!hasDataChanged && forceRender) {
        const now = Date.now();
        if (now - this.lastContainerFixTime < 3000) return; // 3秒强制冷却
        this.lastContainerFixTime = now;
      }

      this.sources = newSources;
      this.notes = newNotes;
      
      console.log(`[NB-Ext] ScanDom: ${hasDataChanged ? 'Data changed' : 'Force re-render (Visibility/Missing)'}. Refreshing...`);
      this.refreshData();

      // 4.28: 重新绑定 Checkbox 监听
      this.sources.concat(this.notes).forEach(item => {
        if (item.checkbox && !item.checkbox.hasNbExtListener) {
          item.checkbox.hasNbExtListener = true;
          item.checkbox.addEventListener('change', () => {
             StorageManager.getNotebookConfig(this.notebookId).then(config => this.renderSidebarUI(config));
          });
        }
      });
    }

    // 4.38: 核心优化：全选状态双向同步联动
    const sidebarContent = document.querySelector('.source-panel-content');
    if (sidebarContent) {
      const selectAllContainer = sidebarContent.querySelector('.select-all-sources-container') || 
                                 sidebarContent.querySelector('.select-checkbox-all-sources-container');
      if (selectAllContainer) {
        // 4.69: 拦截全选容器点击，实现基于过滤状态的按需多选
        if (!selectAllContainer.hasNbExtClickListener) {
          selectAllContainer.hasNbExtClickListener = true;
          selectAllContainer.addEventListener('click', (e) => {
            if (this.searchQuery && this.searchQuery.trim() !== '') {
              e.preventDefault();
              e.stopPropagation();
              
              const visibleItems = Array.from(document.querySelectorAll('.nb-ext-item, .nb-ext-item-row'))
                .filter(el => !el.classList.contains('nb-ext-hidden'));
                
              if (visibleItems.length === 0) return;

              const isAllVisibleSelected = visibleItems.every(el => {
                 const cb = el.querySelector('.nb-ext-checkbox-native');
                 return cb && cb.textContent === 'check_box';
              });

              const targetState = !isAllVisibleSelected;

              visibleItems.forEach(el => {
                const cb = el.querySelector('.nb-ext-checkbox-native');
                if (cb) {
                  const isChecked = cb.textContent === 'check_box';
                  if (isChecked !== targetState) {
                    cb.click();
                  }
                }
              });
              
              setTimeout(() => this.refreshData(), 50);
            }
          }, true); // 必须使用捕获阶段
        }

        // 1. 同步全选 Checkbox
        const allCb = selectAllContainer.querySelector('input[type="checkbox"]');
        if (allCb && !allCb.hasNbExtListener) {
          allCb.hasNbExtListener = true;
          allCb.addEventListener('change', () => {
             console.log("[NB-Ext] Global Select-All changed, triggering deep UI refresh...");
             StorageManager.getNotebookConfig(this.notebookId).then(config => this.renderSidebarUI(config));
          });
        }
        
        // 2. 搜索按钮状态重构：v4.60 不再有静态 Input，此逻辑忽略

        // 3. 4.62: 启动侧边栏尺寸监听
        this.initSidebarObserver(sidebarContent);
      }
    }
  },

  // 4.62: 初始化 ResizeObserver
  initSidebarObserver(target) {
    if (this.sidebarObserver) return;
    
    this.sidebarObserver = new ResizeObserver(entries => {
      for (let entry of entries) {
        const rect = entry.target.getBoundingClientRect();
        this.currentSidebarWidth = rect.width;
        this.currentSidebarLeft = rect.left;
        this.updateSearchPanelPosition();
      }
    });
    this.sidebarObserver.observe(target);
  },

  updateSearchPanelPosition() {
    const panel = document.getElementById('nb-ext-search-panel');
    const sidebarContent = document.querySelector('.source-panel-content');
    if (panel && sidebarContent) {
      const rect = sidebarContent.getBoundingClientRect();
      this.currentSidebarWidth = rect.width;
      this.currentSidebarLeft = rect.left;
      
      // 保留微量边距 (左右各 8px)
      const targetWidth = this.currentSidebarWidth - 16;
      panel.style.width = `${targetWidth}px`;
      panel.style.left = `${this.currentSidebarLeft + 8}px`;
      
      // 4.63: 动态同步底部位置
      panel.style.top = 'unset';
      panel.style.bottom = '20px';
    }
  },

  renderRetryCount: 0,

  async renderSidebarUI(config) {
    if (this.isRendering) return;
    this.isRendering = true;
    
    try {
      if (!config) config = await StorageManager.getNotebookConfig(this.notebookId);
      console.log("[NB-Ext] Render requested.");
    
    // 1. 基于类名精准锁定容器 (符合用户最新指示)
    const sourcePanel = document.querySelector('[class*="source-panel"]');
    const scrollAreaOuter = document.querySelector('.scroll-area-desktop') || document.querySelector('.mat-drawer-inner-container');
    
    let nativeHeader = sourcePanel ? sourcePanel.querySelector('[class*="panel-header"]') : null;
    let sidebarContent = scrollAreaOuter ? scrollAreaOuter.parentElement : (sourcePanel || document.querySelector('.source-panel-content'));

    // 兜底：如果还是找不到 Header，再用文字搜索大法
    if (!nativeHeader) {
      const allButtons = document.querySelectorAll('button');
      for (const btn of allButtons) {
        const text = btn.innerText || '';
        if (/Sources|源|Notes|笔记/.test(text)) {
           nativeHeader = btn.closest('[class*="header"]') || btn.closest('[class*="panel-header"]') || btn.parentElement;
           if (nativeHeader) break;
        }
      }
    }

    if (!sidebarContent && nativeHeader) {
      sidebarContent = nativeHeader.nextElementSibling;
    }
    
    // 如果还没找着，直接找滚动区域，它是 Content 的绝对标志
    if (!sidebarContent) {
      const scrollArea = document.querySelector('.scroll-area-desktop') || document.querySelector('.mat-drawer-inner-container');
      if (scrollArea) {
        sidebarContent = scrollArea.parentElement;
        console.log("[NB-Ext] Content found via ScrollArea anchor.");
      }
    }

    // 2. 自动重试机制：无限重试（1秒间隔）
    if (!sidebarContent || !nativeHeader) {
      console.log(`[NB-Ext] Containers not ready. Retrying in 1000ms...`);
      this.isRendering = false; // 释放锁以允许重试调用
      setTimeout(() => this.renderSidebarUI(config), 1000);
      return; 
    }

    this.renderRetryCount = 0; // 成功后重置计数
    const targetScrollArea = sidebarContent.querySelector('.scroll-area-desktop') || sidebarContent.querySelector('.mat-drawer-inner-container');
    let container = document.getElementById('nb-ext-container');

    // 如果试用期满且未激活，在容器内展示内嵌支付提醒
    if (this.licenseInfo && this.licenseInfo.isExpired) {
      if (!container) {
        container = document.createElement('div');
        container.id = 'nb-ext-container';
        container.className = 'nb-ext-sidebar nb-ext-full-width';
        sidebarContent.appendChild(container); // 4.10: 挂载在父节点末尾（下面）
      }
      this.renderPaywall(false, true); 
      return;
    }
    
    
    // 4.31-4.32: 自适应宿主定位器
    const selectAllContainer = sidebarContent ? (sidebarContent.querySelector('.select-all-sources-container') || sidebarContent.querySelector('.select-checkbox-all-sources-container')) : null;
    const sampleItem = document.querySelector('.single-source-container');
    // 优先采用用户建议的单项祖父节点作为宿主，回退到全选容器父级
    const angularHost = sampleItem ? sampleItem.parentElement?.parentElement : 
                        (selectAllContainer ? selectAllContainer.parentElement : null);
    

    // 4.12: 预处理数据：排序与搜索
    const getFilteredAndSorted = (list) => {
      // 1. 记录原始索引（代表加入时间）
      const listWithMeta = list.map((item, idx) => ({ ...item, originalIndex: idx }));
      
      // 2. 4.63: 过滤逻辑统合至 applyFilter，此处仅处理原始列表索引
      // 移除原有的简易 includes 过滤，统一由 applyFilter 在渲染后处理显示隐藏

      // 直接原样返回（已弃用之前的 sortBy 逻辑）
      return listWithMeta;
    };

    const displaySources = getFilteredAndSorted(this.sources);
    const displayNotes = getFilteredAndSorted(this.notes);

    // 4.20: 挂载 ResizeObserver 监听收缩状态
    if (sidebarContent) {
      if (this.resizeObserver) {
        // 先断开旧的观察逻辑，重新绑定当前活动的 sidebarContent
        this.resizeObserver.disconnect();
        this.resizeObserver.observe(sidebarContent);
      }
    }

    // 4.10: 增强版容器挂载与检查逻辑
    if (!container) {
      container = document.createElement('div');
      container.id = 'nb-ext-container';
      container.className = 'nb-ext-sidebar nb-ext-full-width';
    }
    
    if (!sidebarContent.contains(container)) {
      sidebarContent.appendChild(container); 
      console.log("[NB-Ext] Container mounted at the bottom of SidebarContent.");
    }

    console.log("[NB-Ext] Container status: Rendering folders...");
    container.textContent = ''; 

    // 4.60: 浮动搜索功能。不再常驻顶部 searchContainer
    // 搜索面板渲染逻辑移至 toggleSearchPanel

    const unassignedItems = this.sources.filter(s => 
      !config.folders.some(f => f.itemIds.includes(s.id))
    );

    // Toolbar 样式微调（保持 Header 透明度或对齐）
    if (nativeHeader) {
      nativeHeader.style.position = 'relative'; 
      nativeHeader.style.display = 'flex';
      nativeHeader.style.alignItems = 'center'; 
      nativeHeader.style.justifyContent = 'space-between';
      nativeHeader.style.flexWrap = 'nowrap';
    }

    this.applyFilter();

    // 4.10: 工具栏嵌入顶部 Header
    let toolbar = nativeHeader ? nativeHeader.querySelector('.nb-ext-toolbar') : container.querySelector('.nb-ext-toolbar');
    if (nativeHeader && !toolbar) {
      toolbar = document.createElement('div');
      toolbar.className = 'nb-ext-toolbar';
      
      const headerContent = nativeHeader.querySelector('[class*="panel-header-content"]');
      if (headerContent) {
        headerContent.insertAdjacentElement('afterend', toolbar);
      } else {
        nativeHeader.appendChild(toolbar);
      }
    } else if (!nativeHeader && !toolbar) {
      toolbar = document.createElement('div');
      toolbar.className = 'nb-ext-toolbar';
      container.prepend(toolbar);
    }
    
    if (toolbar) {
      toolbar.textContent = ''; 
    }

      // 4.60: 浮动搜索触发按钮
      const searchTrigger = document.createElement('div');
      searchTrigger.className = `nb-ext-toolbar-icon ${this.isSearchOpen ? 'active' : ''}`;
      const searchTriggerIcon = document.createElement('span');
      searchTriggerIcon.className = 'material-symbols-outlined';
      searchTriggerIcon.textContent = 'search';
      searchTrigger.appendChild(searchTriggerIcon);
      searchTrigger.title = 'Advanced Search (Space=OR, +=AND)';
      searchTrigger.addEventListener('click', (e) => {
        e.stopPropagation();
        this.toggleSearchPanel();
      });
      toolbar.appendChild(searchTrigger);
      
      const viewToggle = document.createElement('div');
      viewToggle.className = `nb-ext-toolbar-icon ${this.treeViewEnabled ? 'active' : ''}`;
      const viewIcon = document.createElement('span');
      viewIcon.className = 'material-symbols-outlined';
      viewIcon.textContent = this.treeViewEnabled ? 'account_tree' : 'view_list';
      viewToggle.appendChild(viewIcon);
      viewToggle.title = this.treeViewEnabled ? '切换到简约列表' : '切换到目录树';
      viewToggle.addEventListener('click', (e) => {
        e.stopPropagation();
        this.treeViewEnabled = !this.treeViewEnabled;
        chrome.storage.local.set({ 'nb_ext_tree_enabled': this.treeViewEnabled });
        this.refreshData();
      });

      const modeToggle = document.createElement('div');
      modeToggle.className = `nb-ext-toolbar-icon`;
      const modeIcon = document.createElement('span');
      modeIcon.className = 'material-symbols-outlined';
      modeIcon.textContent = this.displayMode === 'single' ? 'view_headline' : 'view_agenda';
      modeToggle.appendChild(modeIcon);
      modeToggle.title = this.displayMode === 'single' ? '切换到双行显示' : '切换到单行显示';
      modeToggle.addEventListener('click', (e) => {
        e.stopPropagation();
        this.displayMode = this.displayMode === 'single' ? 'double' : 'single';
        chrome.storage.local.set({ 'nb_ext_display_mode': this.displayMode });
        this.refreshData();
      });

      const addDirBtn = document.createElement('div');
      addDirBtn.className = `nb-ext-toolbar-icon`;
      const addIcon = document.createElement('span');
      addIcon.className = 'material-symbols-outlined';
      addIcon.textContent = 'create_new_folder';
      addDirBtn.appendChild(addIcon);
      addDirBtn.title = 'Create Folder';
      addDirBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        this.isAddingFolder = !this.isAddingFolder;
        this.refreshData();
      });



      toolbar.appendChild(viewToggle);
      toolbar.appendChild(modeToggle);
      toolbar.appendChild(addDirBtn);

      // v1.1.1: 增加激活/购买入口（仅在未授权时显示）
      if (this.licenseInfo && !this.licenseInfo.isLicensed) {
        const licenseBtn = document.createElement('div');
        licenseBtn.className = `nb-ext-toolbar-icon`;
        const licenseIcon = document.createElement('span');
        licenseIcon.className = 'material-symbols-outlined';
        licenseIcon.textContent = 'vpn_key';
        licenseBtn.appendChild(licenseIcon);
        licenseBtn.title = 'Purchase or Activate License';
        licenseBtn.addEventListener('click', (e) => {
          e.stopPropagation();
          this.renderPaywall(true);
        });
        toolbar.appendChild(licenseBtn);
      }

    // Inline Folder Creator
    if (this.isAddingFolder) {
      const creator = document.createElement('div');
      creator.className = 'nb-ext-folder-creator';

      const input = document.createElement('input');
      input.type = 'text';
      input.placeholder = 'Folder name...';
      input.className = 'nb-ext-input';
      
        input.addEventListener('keydown', async (e) => {
          if (e.key === 'Enter' && input.value) {
            await this.addFolderWithName(input.value);
            this.isAddingFolder = false;
            this.refreshData();
          } else if (e.key === 'Escape') {
            this.isAddingFolder = false;
            this.refreshData();
          }
        });

        const saveBtn = document.createElement('div');
        saveBtn.className = 'nb-ext-add-btn';
        saveBtn.textContent = 'Save';
        saveBtn.addEventListener('click', async () => {
          if (input.value) {
            await this.addFolderWithName(input.value);
            this.isAddingFolder = false;
            this.refreshData();
          }
        });

      creator.appendChild(input);
      creator.appendChild(saveBtn);
      container.appendChild(creator);
      setTimeout(() => input.focus(), 100);
    }

    // 4.3: 根据视图模式渲染列表
    if (this.treeViewEnabled) {
      // Tree List
      const folderList = document.createElement('div');
      folderList.id = 'nb-ext-folder-list';
      
      config.folders.forEach(f => {
        const folderDiv = document.createElement('div');
        folderDiv.className = 'nb-ext-folder';

        const isCollapsed = this.collapsedFolderIds.includes(f.id);
        
        folderDiv.className = `nb-ext-folder ${isCollapsed ? 'collapsed' : ''}`;

        const folderTitle = document.createElement('div');
        folderTitle.className = 'nb-ext-folder-title';

        // 4.9: 原生蓝色勾选框 (✓) - 映射原始 Checkbox 状态
        const isAllSelected = f.itemIds.length > 0 && f.itemIds.every(id => {
          const item = [...this.sources, ...this.notes].find(i => i.id === id);
          return item && item.checkbox && item.checkbox.checked;
        });

        const fbBox = document.createElement('span');
        fbBox.className = 'nb-ext-checkbox-native material-symbols-outlined';
        fbBox.textContent = isAllSelected ? 'check_box' : 'check_box_outline_blank';
        fbBox.addEventListener('click', (e) => {
          e.stopPropagation();
          this.toggleFolderSelection(f.id, !isAllSelected);
        });
        folderTitle.appendChild(fbBox);
        
        // 4.9: 增加折叠箭头
        const arrow = document.createElement('span');
        arrow.className = `nb-ext-folder-arrow material-symbols-outlined ${isCollapsed ? '' : 'expanded'}`;
        arrow.textContent = 'chevron_right';
        folderTitle.appendChild(arrow);

        const icon = document.createElement('span');
        icon.className = 'nb-ext-folder-icon material-symbols-outlined';
        icon.textContent = isCollapsed ? 'folder' : 'folder_open';
        folderTitle.appendChild(icon);

        if (this.editingFolderId === f.id) {
          // 4.35: 行内编辑模式
          const nameInput = document.createElement('input');
          nameInput.type = 'text';
          nameInput.className = 'nb-ext-inline-edit-input';
          nameInput.value = f.name;
          nameInput.addEventListener('click', (e) => e.stopPropagation());
          nameInput.addEventListener('keydown', async (e) => {
            if (e.key === 'Enter') {
              if (nameInput.value) await this.renameFolder(f.id, nameInput.value);
              this.editingFolderId = null;
              this.refreshData();
            } else if (e.key === 'Escape') {
              this.editingFolderId = null;
              this.refreshData();
            }
          });
          nameInput.addEventListener('blur', async () => {
             if (this.editingFolderId === f.id) {
               if (nameInput.value && nameInput.value !== f.name) {
                 await this.renameFolder(f.id, nameInput.value);
               }
               this.editingFolderId = null;
               this.refreshData();
             }
          });
          folderTitle.appendChild(nameInput);
          setTimeout(() => nameInput.focus(), 50);
        } else {
          const nameSpan = document.createElement('span');
          nameSpan.className = 'nb-ext-text-truncate nb-ext-folder-name';
          // 4.28: 增加目录文件数统计样式：目录名 (数量)
          nameSpan.textContent = `${f.name} (${f.itemIds.length})`;
          // 点击整行切换折叠
          folderTitle.addEventListener('click', () => {
            if (isCollapsed) {
              this.collapsedFolderIds = this.collapsedFolderIds.filter(id => id !== f.id);
            } else {
              this.collapsedFolderIds.push(f.id);
            }
            chrome.storage.local.set({ 'nb_ext_collapsed_ids': this.collapsedFolderIds });
            this.refreshData();
          });
          folderTitle.appendChild(nameSpan);
        }

        const editBtn = document.createElement('span');
        editBtn.className = 'nb-ext-action-icon material-symbols-outlined';
        editBtn.textContent = 'edit';
        editBtn.title = 'Rename Folder';
        editBtn.addEventListener('click', (e) => {
          e.stopPropagation();
          this.editingFolderId = f.id;
          this.refreshData();
        });

        const delBtn = document.createElement('span');
        delBtn.className = 'nb-ext-action-icon material-symbols-outlined';
        delBtn.textContent = 'delete';
        delBtn.title = 'Delete Folder';
        delBtn.addEventListener('click', async (e) => {
          e.stopPropagation();
          const choice = confirm(`[OK]: Delete folder only\n[Cancel]: Delete folder AND its documents`);
          if (choice) await this.removeFolderOnly(f.id);
          else await this.removeFolderAndItems(f.id);
        });
        
        folderTitle.appendChild(editBtn);
        folderTitle.appendChild(delBtn);
        folderDiv.appendChild(folderTitle);

        if (!isCollapsed) {
          const folderContent = document.createElement('div');
          folderContent.className = 'nb-ext-folder-content';

          f.itemIds.forEach(itemId => {
            const item = [...this.sources, ...this.notes].find(i => i.id === itemId);
            if (item) {
              const itemDiv = document.createElement('div');
              itemDiv.className = `nb-ext-item nb-ext-display-${this.displayMode}`;

              const isItemSelected = item.checkbox ? item.checkbox.checked : false;
              const itemBox = document.createElement('span');
              itemBox.className = 'nb-ext-checkbox-native material-symbols-outlined';
              itemBox.textContent = isItemSelected ? 'check_box' : 'check_box_outline_blank';
              itemBox.addEventListener('click', (e) => {
                e.stopPropagation();
                if (item.checkbox) item.checkbox.click();
              });
              itemDiv.appendChild(itemBox);

              const itemIcon = document.createElement('span');
              itemIcon.className = 'nb-ext-item-icon material-symbols-outlined';
              itemIcon.textContent = this.getFileIcon(item.name);
              itemDiv.appendChild(itemIcon);

              const label = document.createElement('span');
              label.className = 'nb-ext-source-label';
              label.textContent = item.name;
              label.onclick = () => item.element.click();
              itemDiv.appendChild(label);

              // 4.8: 浮动归类
              itemDiv.appendChild(this.createMoveTrigger(item));

              folderContent.appendChild(itemDiv);
            }
          });
          folderDiv.appendChild(folderContent);
        }
        folderList.appendChild(folderDiv);
      });
      
      container.appendChild(folderList);

      // Unassigned List (仅在 Tree 模式下显示待分类标题)
      const unassignedDiv = document.createElement('div');
      unassignedDiv.className = 'nb-ext-unassigned';
      
      const unassignedTitle = document.createElement('div');
      unassignedTitle.className = 'nb-ext-unassigned-title';
      unassignedTitle.textContent = `Unassigned (${unassignedItems.length})`;
      unassignedDiv.appendChild(unassignedTitle);

      unassignedItems.forEach(item => {
        unassignedDiv.appendChild(this.createItemRow(item));
      });

      container.appendChild(unassignedDiv);
    } else {
      // 4.3: 简约列表模式 - 平铺所有文件，不显示文件夹/待分类
      const flatList = document.createElement('div');
      flatList.className = 'nb-ext-flat-list';
      
      this.sources.forEach(item => {
        flatList.appendChild(this.createItemRow(item));
      });
      
      container.appendChild(flatList);
    }

    // 4.65: 渲染循环最后一步，强制执行精准对齐与显隐检测
    this.syncContainerSize();
    // 4.63: 渲染循环最后一步，强制应用搜索过滤
    this.applyFilter();
    } catch (err) {
      console.error("[NB-Ext] Render Error:", err);
    } finally {
      this.isRendering = false;
    }
  },

  // 4.3: 提取通用行构建方法
  createItemRow(item) {
    const row = document.createElement('div');
    row.className = `nb-ext-item-row nb-ext-display-${this.displayMode}`;

    const isItemSelected = item.checkbox ? item.checkbox.checked : false;
    const itemBox = document.createElement('span');
    itemBox.className = 'nb-ext-checkbox-native material-symbols-outlined';
    itemBox.textContent = isItemSelected ? 'check_box' : 'check_box_outline_blank';
    itemBox.addEventListener('click', (e) => {
      e.stopPropagation();
      if (item.checkbox) item.checkbox.click();
    });
    row.appendChild(itemBox);

    const itemIcon = document.createElement('span');
    itemIcon.className = 'nb-ext-item-icon material-symbols-outlined';
    itemIcon.textContent = this.getFileIcon(item.name);
    row.appendChild(itemIcon);

    const itemLabel = document.createElement('div');
    itemLabel.className = 'nb-ext-source-label';
    itemLabel.textContent = item.name;
    itemLabel.onclick = () => item.element.click();
    row.appendChild(itemLabel);

    // 4.8: 浮动归类
    row.appendChild(this.createMoveTrigger(item));
    
    return row;
  },

  // 4.8 & 4.9: 提取浮动归类逻辑
  createMoveTrigger(item) {
    const moveTrigger = document.createElement('div');
    moveTrigger.className = 'nb-ext-move-trigger';
    const moveIcon = document.createElement('span');
    moveIcon.className = 'material-symbols-outlined';
    moveIcon.textContent = 'folder_open';
    moveTrigger.appendChild(moveIcon);
    
    const select = document.createElement('select');
    const defaultOpt = document.createElement('option');
    defaultOpt.value = '';
    defaultOpt.textContent = 'Move to...';
    select.appendChild(defaultOpt);

    StorageManager.getNotebookConfig(this.notebookId).then(config => {
      config.folders.forEach(f => {
        const opt = document.createElement('option');
        opt.value = f.id;
        opt.textContent = f.name;
        select.appendChild(opt);
      });
    });

    select.addEventListener('change', (e) => {
      this.moveItemToFolder(item.id, e.target.value);
    });
    
    moveTrigger.appendChild(select);
    return moveTrigger;
  },

  // 4.11: 后缀名识别
  getFileIcon(filename) {
    if (!filename) return 'description';
    const ext = filename.split('.').pop().toLowerCase();
    const map = {
      'pdf': 'picture_as_pdf',
      'doc': 'article', 'docx': 'article',
      'xls': 'table_view', 'xlsx': 'table_view', 'csv': 'table_view',
      'ppt': 'present_to_all', 'pptx': 'present_to_all',
      'png': 'image', 'jpg': 'image', 'jpeg': 'image', 'gif': 'image', 'webp': 'image',
      'txt': 'notes', 'md': 'description',
      'zip': 'folder_zip', 'rar': 'folder_zip', '7z': 'folder_zip',
      'html': 'html', 'js': 'javascript', 'css': 'css',
      'mp3': 'audio_file', 'wav': 'audio_file',
      'mp4': 'video_file', 'mov': 'video_file'
    };
    return map[ext] || 'description';
  },

  async toggleFolderSelection(folderId, isChecked) {
    const config = await StorageManager.getNotebookConfig(this.notebookId);
    const folder = config.folders.find(f => f.id === folderId);
    if (!folder) return;

    folder.itemIds.forEach(itemId => {
      const item = [...this.sources, ...this.notes].find(i => i.id === itemId);
      if (item && item.checkbox && item.checkbox.checked !== isChecked) {
        // 4.26: 增强派发，确保 Angular 监听 change 事件
        item.checkbox.checked = isChecked;
        item.checkbox.dispatchEvent(new Event('change', { bubbles: true }));
        item.checkbox.dispatchEvent(new Event('input', { bubbles: true }));
        item.checkbox.click(); // 保留 click 以触发点击行为相关的 UI 更新
      }
    });

    // 强制触发一次 UI 刷新（图标状态）
    this.renderSidebarUI(config);
  },

  // 4.60: 触发/渲染浮动搜索面板
  toggleSearchPanel() {
    this.isSearchOpen = !this.isSearchOpen;
    let panel = document.getElementById('nb-ext-search-panel');
    
    if (this.isSearchOpen) {
      if (!panel) {
        panel = document.createElement('div');
        panel.id = 'nb-ext-search-panel';
        panel.className = 'nb-ext-search-panel';
        document.body.appendChild(panel);
      }
      // 4.62: 初次渲染立即同步位置
      this.updateSearchPanelPosition();

      panel.textContent = ''; // 清空内容

      const box = document.createElement('div');
      box.className = 'nb-ext-search-box';

      const hintIcon = document.createElement('span');
      hintIcon.className = 'material-symbols-outlined search-hint-icon';
      hintIcon.textContent = 'search';

      const input = document.createElement('input');
      input.type = 'text';
      input.className = 'nb-ext-search-input-float';
      input.placeholder = 'Advanced Search... (Space=OR, +=AND)';
      input.value = this.searchQuery;

      const closeIcon = document.createElement('span');
      closeIcon.className = 'material-symbols-outlined search-close-icon';
      closeIcon.textContent = 'close';
      closeIcon.addEventListener('click', () => this.toggleSearchPanel());

      box.append(hintIcon, input, closeIcon);

      const help = document.createElement('div');
      help.className = 'nb-ext-search-help';
      help.textContent = 'Example: "doc pdf + 2025" matches (doc OR pdf) AND 2025';

      panel.append(box, help);
      
      setTimeout(() => input.focus(), 50);
      
      // 4.61: 增加 IME 支持
      input.addEventListener('compositionstart', () => { this.isComposing = true; });
      input.addEventListener('compositionend', (e) => {
        this.isComposing = false;
        this.searchQuery = e.target.value;
        this.applyFilter();
      });

      input.addEventListener('input', (e) => {
        if (this.isComposing) return; // 4.61: 拼音输入过程中不触发过滤
        this.searchQuery = e.target.value;
        this.applyFilter();
      });

      input.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') this.toggleSearchPanel();
      });

      panel.querySelector('.search-close-icon').addEventListener('click', () => {
        this.toggleSearchPanel();
      });

      // 同步工具栏按钮深度状态
      this.refreshToolbarStatus();
    } else {
      if (panel) panel.remove();
      // 4.71: 搜索框消失时，取消过滤
      this.searchQuery = '';
      this.applyFilter();
      
      this.refreshToolbarStatus();
    }
  },

  refreshToolbarStatus() {
     const trigger = document.querySelector('.nb-ext-toolbar-icon:has(span[textContent="search"])');
     if (trigger) {
       trigger.classList.toggle('active', this.isSearchOpen);
     }
  },

  // 4.60: 高级过滤逻辑：+ = AND, Space = OR
  applyFilter() {
    const query = this.searchQuery.trim().toLowerCase();
    const items = document.querySelectorAll('.nb-ext-item, .nb-ext-item-row');
    const folders = document.querySelectorAll('.nb-ext-folder');
    const unassignedArea = document.querySelector('.nb-ext-unassigned');
    const sidebarContent = document.querySelector('.source-panel-content');
    const targetScrollArea = sidebarContent?.querySelector('.scroll-area-desktop') || sidebarContent?.querySelector('.mat-drawer-inner-container');

    // 逻辑引擎：
    // 1. 按 '+' 分割必选组 (AND)
    // 2. 每组内按 空格 分割备选项 (OR)
    const andGroups = query.split('+').map(g => g.trim()).filter(g => g);

    const matches = (text) => {
      text = text.toLowerCase();
      if (!query) return true;
      
      // 必须满足每一个 AND 组
      return andGroups.every(group => {
        const orTerms = group.split(/\s+/).filter(t => t);
        // 组内只要命中一个任一 Term 即代表该组满足 (OR)
        return orTerms.some(term => text.includes(term));
      });
    };

    items.forEach(el => {
      const text = el.querySelector('.nb-ext-source-label')?.textContent || el.textContent;
      const isVisible = matches(text);
      // 4.64: 改用 classList 切换，避免被 CSS 中的 !important 覆盖
      if (isVisible) el.classList.remove('nb-ext-hidden');
      else el.classList.add('nb-ext-hidden');
    });

    // 树模式下的目录也要检查是否有子节点可见
    folders.forEach(el => {
      if (!query) {
        el.classList.remove('nb-ext-hidden');
        return;
      }
      const hasVisibleChild = Array.from(el.querySelectorAll('.nb-ext-item'))
        .some(item => !item.classList.contains('nb-ext-hidden'));
      
      if (hasVisibleChild) el.classList.remove('nb-ext-hidden');
      else el.classList.add('nb-ext-hidden');
      
      if (hasVisibleChild) {
        el.classList.remove('collapsed');
        const arrow = el.querySelector('.nb-ext-folder-arrow');
        if (arrow) arrow.classList.add('expanded');
      }
    });

    // 4.61: 待分类区域过滤与标题状态同步
    if (unassignedArea) {
      if (!query) {
        unassignedArea.classList.remove('nb-ext-hidden');
        const title = unassignedArea.querySelector('.nb-ext-unassigned-title');
        if (title) title.classList.remove('nb-ext-hidden');
      } else {
        const hasVisibleItem = Array.from(unassignedArea.querySelectorAll('.nb-ext-item-row'))
          .some(item => !item.classList.contains('nb-ext-hidden'));
        
        if (hasVisibleItem) unassignedArea.classList.remove('nb-ext-hidden');
        else unassignedArea.classList.add('nb-ext-hidden');
        
        const title = unassignedArea.querySelector('.nb-ext-unassigned-title');
        if (title) {
          if (hasVisibleItem) title.classList.remove('nb-ext-hidden');
          else title.classList.add('nb-ext-hidden');
        }
      }
    }
    
    // 4.10: 采用绝对定位覆盖方案，此处不再操作 display: none。
    // UI 始终由 main.css 中的 #nb-ext-container { position: absolute } 覆盖原生内容。
  },

  async addFolderWithName(name) {
    const config = await StorageManager.getNotebookConfig(this.notebookId);
    config.folders.push({
      id: Date.now().toString(),
      name: name,
      itemIds: []
    });
    await StorageManager.saveNotebookConfig(this.notebookId, config);
  },

  async renameFolder(folderId, newName) {
    const config = await StorageManager.getNotebookConfig(this.notebookId);
    const folder = config.folders.find(f => f.id === folderId);
    if (folder) {
      folder.name = newName;
      await StorageManager.saveNotebookConfig(this.notebookId, config);
      this.refreshData();
    }
  },

  async removeFolderOnly(folderId) {
    const config = await StorageManager.getNotebookConfig(this.notebookId);
    config.folders = config.folders.filter(f => f.id !== folderId);
    await StorageManager.saveNotebookConfig(this.notebookId, config);
    this.refreshData();
  },

  async removeFolderAndItems(folderId) {
    const config = await StorageManager.getNotebookConfig(this.notebookId);
    const folder = config.folders.find(f => f.id === folderId);
    
    if (folder) {
      // 这里的“彻底删除文档”需要谨慎实现。
      // 因为我们没有 API，只能尝试触发原生的删除 UI。
      // 由于这涉及多个步骤且极易出错，目前的策略是：
      // 将文件夹及其关联的数据从插件存储中移除。
      // 注意：由于无法可靠地批量点击原生的“删除”并确认，
      // 我们在此告知用户需要手动在 NotebookLM 中删除 Source。
      alert("插件已移除文件夹配置。请注意：插件无法直接删除 NotebookLM 内部的原始文档，请手动删除它们。");
      
      config.folders = config.folders.filter(f => f.id !== folderId);
      await StorageManager.saveNotebookConfig(this.notebookId, config);
      this.refreshData();
    }
  },

  async moveItemToFolder(itemId, folderId) {
    // 4.1: 记录当前滚动位置，防止归档后跳转
    const sidebarContent = document.querySelector('.source-panel-content');
    const lastScrollTop = sidebarContent ? sidebarContent.scrollTop : 0;

    const config = await StorageManager.getNotebookConfig(this.notebookId);
    
    config.folders.forEach(f => {
      f.itemIds = f.itemIds.filter(id => id !== itemId);
    });

    if (folderId) {
      const folder = config.folders.find(f => f.id === folderId);
      if (folder) folder.itemIds.push(itemId);
    }

    await StorageManager.saveNotebookConfig(this.notebookId, config);
    
    await this.refreshData();

    // 4.1: 恢复滚动位置
    if (sidebarContent) {
      sidebarContent.scrollTop = lastScrollTop;
    }
  },

  renderPaywall(isManualOpen = false, isInline = false) {
    const paywallId = isInline ? 'nb-ext-paywall-inline' : 'nb-ext-paywall';
    let paywall = document.getElementById(paywallId);
    
    if (!paywall) {
      paywall = document.createElement('div');
      paywall.id = paywallId;
      paywall.className = isInline ? 'nb-ext-paywall-inline' : 'nb-ext-paywall';
      
      if (isInline) {
        const container = document.getElementById('nb-ext-container');
        if (container) container.appendChild(paywall);
      } else {
        document.body.appendChild(paywall);
      }
    }

    // 处理背景点击关闭（仅限手动打开且非强制过期）
    if (!isInline && isManualOpen && !this.licenseInfo.isExpired) {
      paywall.onclick = (e) => {
        if (e.target === paywall) paywall.remove();
      };
      
      const escHandler = (e) => {
        if (e.key === 'Escape') {
          paywall.remove();
          document.removeEventListener('keydown', escHandler);
        }
      };
      document.addEventListener('keydown', escHandler);
    }

    const trialDaysLeft = Math.max(0, this.licenseInfo.trialDays - Math.floor((Date.now() - this.licenseInfo.installDate) / (24 * 60 * 60 * 1000)));

    paywall.textContent = ''; // 清空内容

    const modal = document.createElement('div');
    modal.className = 'nb-ext-paywall-modal';
    paywall.appendChild(modal);

    // 如果是手动打开且非内嵌，添加关闭按钮
    if (!isInline && isManualOpen && !this.licenseInfo.isExpired) {
      const closeBtn = document.createElement('span');
      closeBtn.className = 'material-symbols-outlined';
      closeBtn.style.cssText = 'position:absolute; top:16px; right:16px; cursor:pointer; color:#5f6368; font-size:20px;';
      closeBtn.textContent = 'close';
      closeBtn.onclick = () => paywall.remove();
      modal.appendChild(closeBtn);
    }

    const icon = document.createElement('span');
    icon.className = 'material-symbols-outlined nb-ext-paywall-icon';
    icon.textContent = this.licenseInfo.isExpired ? 'lock' : 'verified_user';

    const title = document.createElement('div');
    title.className = 'nb-ext-paywall-title';
    title.textContent = this.licenseInfo.isExpired ? 'Trial Period Expired' : 'NotebookLM Enhancer';

    const desc = document.createElement('div');
    desc.className = 'nb-ext-paywall-desc';
    desc.textContent = this.licenseInfo.isExpired ? 
      'Your 7-day free trial of NotebookLM Enhancer has ended. Purchase a lifetime license to continue using directory management and advanced search.' :
      `You are currently using a free trial. ${trialDaysLeft} days remaining. Upgrade now to unlock lifetime access.`;

    const inputGroup = document.createElement('div');
    inputGroup.className = 'nb-ext-license-input-group';

    const input = document.createElement('input');
    input.type = 'text';
    input.className = 'nb-ext-license-input';
    input.id = isInline ? 'nb-ext-license-key-input-inline' : 'nb-ext-license-key-input';
    input.placeholder = 'Enter License Key...';

    const btn = document.createElement('button');
    btn.className = 'nb-ext-activate-btn';
    btn.textContent = 'Activate Lifetime Access';

    const errorDiv = document.createElement('div');
    errorDiv.className = 'nb-ext-license-error';
    errorDiv.style.display = 'none';

    inputGroup.append(input, btn, errorDiv);

    const buyLink = document.createElement('a');
    buyLink.href = 'https://gumroad.com/l/cxzucm';
    buyLink.target = '_blank';
    buyLink.className = 'nb-ext-buy-link';
    buyLink.textContent = "Don't have a key? Buy it on Gumroad";

    modal.append(icon, title, desc, inputGroup, buyLink);

    btn.onclick = async () => {
      const key = input.value.trim();
      if (!key) return;

      btn.disabled = true;
      btn.textContent = 'Verifying...';
      errorDiv.style.display = 'none';

      try {
        const success = await this.verifyLicense(key);
        if (success) {
          location.reload(); 
        } else {
          errorDiv.textContent = 'Invalid license key. Please check and try again.';
          errorDiv.style.display = 'block';
          btn.disabled = false;
          btn.textContent = 'Activate Lifetime Access';
        }
      } catch (err) {
        errorDiv.textContent = 'Verification error. Please try again later.';
        errorDiv.style.display = 'block';
        btn.disabled = false;
        btn.textContent = 'Activate Lifetime Access';
      }
    };
  },

  async verifyLicense(licenseKey) {
    // Gumroad API 验证
    // https://gumroad.com/dev#licenses
    try {
      const params = new URLSearchParams();
      params.append('product_id', '9KnEA4Z1DE6BlSSJRqONvg==');
      params.append('license_key', licenseKey);

      const response = await fetch('https://api.gumroad.com/v2/licenses/verify', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: params.toString()
      });

      if (!response.ok) {
        const errorText = await response.text();
        console.error("[NB-Ext] Verify API 500/Error:", response.status, errorText);
        return false;
      }

      const data = await response.json();
      
      if (data.success && !data.uses_limit_reached) {
        await StorageManager.setLicense(licenseKey, true);
        return true;
      }
      return false;
    } catch (error) {
      console.error("[NB-Ext] License verification failed:", error);
      throw error;
    }
  }
};

// 延迟初始化以确保 DOM 加载
setTimeout(() => NotebookManager.init(), 2000);
